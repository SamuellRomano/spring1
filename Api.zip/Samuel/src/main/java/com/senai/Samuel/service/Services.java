package com.senai.Samuel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.Samuel.entities.Cliente;
import com.senai.Samuel.repository.repositories;
@Service
public class Services {
	private final repositories repositories;
	
	@Autowired
	public Services(repositories repositories) {
		this.repositories = repositories;
	}
	
	public Cliente saveCliente(Cliente cliente) {
		return repositories.save(cliente);
	}
	
	public Cliente getClienteById(long idcCliente) {
		return repositories.findById(idcCliente).orElse(null);
	}
	
	public List<Cliente> getAllClientes(){
		return repositories.findAll();
	}
	
	public void deleteCliente(Long idcCliente) {
		repositories.deleteById(idcCliente);
	}
}
