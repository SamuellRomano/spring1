package com.senai.Samuel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.Samuel.entities.Cliente;

public interface repositories extends JpaRepository<Cliente, Long> {

}
