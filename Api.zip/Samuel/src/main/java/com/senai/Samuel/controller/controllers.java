package com.senai.Samuel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senai.Samuel.service.Services;
import com.senai.Samuel.entities.Cliente;


@RestController
@RequestMapping("/Cliente")
public class controllers {
	private final Services services;
	
	@Autowired
	public controllers(Services services) {
		this.services = services;
	}
	
	@PostMapping
	public Cliente createCliente(@RequestBody Cliente cliente) {
		return services.saveCliente(cliente);
	}
	
	@GetMapping("/{idcCliente}")
	public Cliente getCliente(@PathVariable Long idcCliente) {
		return services.getClienteById(idcCliente);
	}
	
	@GetMapping
	public List<Cliente> getAllClientes() {
		return services.getAllClientes();
	}
	
	@DeleteMapping("/{idcCliente}")
	public void deleteCliente(@PathVariable Long idcCliente) {
		services.deleteCliente(idcCliente);
	}
}
